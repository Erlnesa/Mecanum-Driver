#include "sys.h"

u32 f_kalman_fliter(u32 z_measure);

