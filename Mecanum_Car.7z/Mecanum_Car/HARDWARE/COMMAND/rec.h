#ifndef __REC_H
#define __REC_H

#include "sys.h" 

void rec(u8 i);

#endif
