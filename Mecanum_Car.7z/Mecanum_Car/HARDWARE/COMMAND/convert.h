#ifndef __CONVERT_H
#define __CONVERT_H 			   
#include "sys.h"

long int convert(u8 bit1,u8 bit2);
long int convert_t(u8 bit1,u8 bit2);

#endif
