#include <sys.h>	 



void TIM8_PWM_Init(u16 arr,u16 psc);
void Motor_Init(void);

